import "./style.css";

const OtpField = (props) => {
  return <input className="otp__field" type="text" maxLength="1"></input>;
};

export default OtpField;
