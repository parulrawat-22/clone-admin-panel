import "./style.css";
import StickerTable from "../../components/Table/StickerTable";

const Sticker = () => {
  return <StickerTable />;
};

export default Sticker;
