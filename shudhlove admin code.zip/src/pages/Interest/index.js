import InterestTable from "../../components/Table/InterestTable";
import "./style.css";

const Interest = () => {
  return (
    <div>
      <InterestTable />
    </div>
  );
};

export default Interest;
