import AcceptedHostTable from "../../components/Table/AcceptedHostTable";
import "./style.css";

const AcceptedHost = () => {
  return <AcceptedHostTable />;
};

export default AcceptedHost;
