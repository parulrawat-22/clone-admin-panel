import { useEffect } from "react";
import { LineChart } from "@mui/x-charts/LineChart";
