export const AppColor = {
  colorWhite: "#FFFFFF",
  colorBlack: "#000000",
};
