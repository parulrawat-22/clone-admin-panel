// import "./style.css";

// import dashboard from "../../base/Assets/sidebarIcon/dashboard.png";
// import user from "../../base/Assets/sidebarIcon/user.png";
// import host from "../../base/Assets/sidebarIcon/host.png";
// import leader from "../../base/Assets/sidebarIcon/leader.png";
// import banner from "../../base/Assets/sidebarIcon/banner (1).png";
// import coin from "../../base/Assets/sidebarIcon/wallet.png";
// import report from "../../base/Assets/sidebarIcon/report.png";
// import gift from "../../base/Assets/sidebarIcon/gift.png";
// import sticker from "../../base/Assets/sidebarIcon/sticker.png";
// import moment from "../../base/Assets/sidebarIcon/camera (1).png";
// import feedback from "../../base/Assets/sidebarIcon/feedback.png";
// import notification from "../../base/Assets/sidebarIcon/notifications.png";
// import topgrowing from "../../base/Assets/sidebarIcon/top growing.png";
// import suspend from "../../base/Assets/sidebarIcon/suspended.png";
// import warning from "../../base/Assets/sidebarIcon/warning.png";

// const sidebarData = [
//   {
//     label: "Dashboard",
//     link: "/dashboard",
//     icon: dashboard,
//   },

//   {
//     label: "All Users ",
//     link: "/allusers?appType=catchwoo",
//     icon: user,
//   },

//   {
//     label: "Host Request",
//     link: "/hostrequest",
//     icon: host,
//   },

//   {
//     label: "Accepted Host",
//     link: "/acceptedhost",
//     icon: host,
//   },

//   {
//     label: "Rejected Host",
//     link: "/rejectedhost",
//     icon: host,
//   },

//   {
//     label: "Leader",
//     link: "/leader",
//     icon: leader,
//   },

//   {
//     label: "Suspended Data",
//     link: "/suspendusers",
//     icon: suspend,
//   },

//   {
//     label: "Warned Data",
//     link: "/warnedusers",
//     icon: warning,
//   },

//   {
//     label: "Banner",
//     link: "/banner",
//     icon: banner,
//   },
//   {
//     label: "Coin",
//     link: "/coin",
//     icon: coin,
//   },

//   {
//     label: "Report",
//     link: "/report",
//     icon: report,
//   },
//   {
//     label: "Gift",
//     link: "/gift",
//     icon: gift,
//   },
//   {
//     label: "Sticker",
//     link: "/sticker",
//     icon: sticker,
//   },

//   {
//     label: "Top Growing",
//     link: "/topgrowing",
//     icon: topgrowing,
//   },

//   {
//     label: "Moment",
//     link: "/moment",
//     icon: moment,
//   },

//   {
//     label: "Interest",
//     link: "/interest",
//     icon: moment,
//   },

//   {
//     label: "Feedback",
//     link: "/feedback",
//     icon: feedback,
//   },

//   {
//     label: "Sub-Admin",
//     link: "/subAdmin",
//     icon: feedback,
//   },

//   {
//     label: "Notification",
//     link: "/notification",
//     icon: notification,
//   },
// ];

// export default sidebarData;
