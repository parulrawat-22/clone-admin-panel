export default "https://apiclone.kickrtechnology.online/api/";
